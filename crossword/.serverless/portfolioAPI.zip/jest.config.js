module.exports = {
  verbose: true,
  testPathIgnorePatterns: ['/node_modules/'],
  setupFiles: ['dotenv/config'],
};
